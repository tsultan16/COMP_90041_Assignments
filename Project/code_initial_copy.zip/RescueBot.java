import java.lang.Math;

/**
 * COMP90041, Sem1, 2023: Final Project
 * @author: 
 * student id: 
 * student email: 
 */
public class RescueBot {

    /**
     * Decides whether to save the passengers or the pedestrians
     * @param Scenario scenario: the ethical dilemma
     * @return Decision: which group to save
     */
    public static Location decide(Scenario scenario) {
        // a very simple decision engine
        // TODO: take into account at least 5 characteristics
        
        // 50/50
        if(Math.random() > 0.5) {
            return scenario.getLocation(1);
        } else {
            return scenario.getLocation(2);
        }
    }

    /**
     * Program entry
     */
    public static void main(String[] args) {
        
    }
}
